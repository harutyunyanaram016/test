var downHere = document.getElementById('downHere');
var silka = "<a href='https://ya.ru/'>ссылке</a>"
var date = new Date();
var day = date.getDate();
var removeDay = date.getDate()-6;
var key = Number(day);
var today=new Date();
var lastWeekDate = new Date(today.setDate(today.getDate() - 3));
var date1 = lastWeekDate;

if(!localStorage['post_date11']){
    localStorage['post_date11'] = (date1.getDate() - 3)+"/"+(date1.getMonth()+1)+"/"+date1.getFullYear();
}

if(!localStorage['comm_date11']){
    localStorage['comm_date11'] = (date.getHours() - 2)+ ":"+date.getMinutes();
}
if(!localStorage['comm_date21']){
    localStorage['comm_date21'] = (date.getHours() - 1)+ ":"+date.getMinutes();
}
$(".block-data").html(localStorage['post_date11']);
$("#comm-date1").html(localStorage['comm_date11']);
$("#comm-date2").html(localStorage['comm_date21']);
if(localStorage['a2']){
    var a = localStorage['a2'];
}else{
    a = 0;
}
var chatbox = 0;
var status = 0;
if(localStorage['status3']){
    status = localStorage['status3'];
}else{
    localStorage['status3'] = 0;
}


for (var i = key; i > key - 5; i--) {
    if (localStorage['chat3_' + i]) {
        document.getElementById('an').insertAdjacentHTML('afterend', localStorage['chat3_' + i])
    }else{
        localStorage['chat3_' + i]
    }
}
var limit = (localStorage['limit22'] > 0) ? localStorage['limit22'] : 0;


for (var i = 0; i <= localStorage['limit22']; i++) {
    $("#downHere").addClass("hidden");
    $(".add-comm").removeClass('hidden');
    downHere.insertAdjacentHTML('beforeBegin',localStorage['key22' + i])
}

if(status == 1){
    document.getElementById('stat').style = 'color:red'
    document.getElementById('stat').innerText = 'Offline'
}

var mode = "";
if(localStorage['mode2']){
    mode = localStorage['mode2'];
}else{
    localStorage['mode2'] = ''
}
var alreadyOpened = false;
(function ($) {
    $("#chat-content-box1").click(function () {
        console.log(1000000000000000000000);
        $(".chat-content").css("display", "none");
        $("body").css("overflow", "auto");
    })
    $(document).ready(function () {
        $(".chat-icon").click(function () {
            iconRefrash(true);
            if(a == 0){
                $('.admin_writing').removeClass('hidden');
            }

            console.log(alreadyOpened);
            console.log(a);
            if(mode == ''){
                mode = "CHAT";
                localStorage['mode2'] = 'CHAT';
            }

            try {
                $(".chat-content").css("display", "block")
                $('.chat-content').toggle("slide", {direction: "right"}, 5000)
                $("body").css("overflow", "hidden")
                chatbox = 1;

            } catch (e) {

            } finally {
                var win = document.getElementById('win'),
                    time = new Date(),
                    now = "" + time.getHours() + ":"
                        + time.getMinutes()
                console.log(a);
                if (!alreadyOpened) {
                    alreadyOpened = true;
                    if (a == 0) {
                        localStorage['a2'] = 1
                        setTimeout(function () {
                            iconRefrash(false)
                            var gtml = `<div class="chat__comment bot"><div class="content">Здравствуйте!<br>Вы хотите что-то спросить о товаре?<br>Чем могу помочь?</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                            win.insertAdjacentHTML('beforeEnd', gtml)
                            $('.admin_writing').addClass('hidden');
                            var date = new Date();
                            var day = date.getDate();
                            localStorage["chat3_" + day] = gtml
                        }, 6000)
                        a++
                    }
                }
            }

        });

        $("#popchat").on('keyup', function (e) {
            iconRefrash(true);
            var code = e.which;

            if (event.which == 13) {
                console.log(a);
                console.log(mode);
                var gtml;
                var text = document.getElementById('popchat').value;
                document.getElementById('popchat').value = ""
                if (isValid(text)) {
                    if (isGoodMesssag(text)) {
                        var time = new Date(),
                            win = document.getElementById('win'),
                            now = ""
                                + time.getHours() + ":"
                                + time.getMinutes();

                        var gtml = `<div class="chat__comment"><div class="content">${text}</div><div class="message-info"><p>Вы:</p>${now}</div></div>`
                        win.insertAdjacentHTML('beforeEnd', gtml)
                        var date = new Date();
                        var day = date.getDate();
                        localStorage["chat3_" + day] += gtml
                        if(status != 1){
                            $('.admin_writing').removeClass('hidden');
                        }
                        if (a == 1) {
                            localStorage['a2'] = 2;
                            $('.admin_writing').removeClass('hidden');
                            if (mode == "COMMENT") {
                                console.log(100312312)
                                setTimeout(function () {

                                    iconRefrash(false);
                                    var gtml = `<div class="chat__comment bot"><div class="content">Здесь официальный сайт товара, подробно консультируют только по телефону<br>Всего доброго!</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                                    win.insertAdjacentHTML('beforeEnd', gtml);
                                    $('.admin_writing').addClass('hidden');
                                    var date = new Date();
                                    var day = date.getDate();
                                    localStorage["chat3_" + day] += gtml
                                }, 4000)
                            } else if (mode == "WAITING") {
                                console.log(34)
                                setTimeout(function () {
                                    iconRefrash(false);
                                    var gtml = `<div class="chat__comment bot"><div class="content">Перейдите по этой ${silka} и заполните форму заказа, вам позвонят и ответят по телефону. Решать заказывать товар или нет, лучше после общения голосом.Вы в любой момент можете согласиться или отказаться от покупки.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                                    win.insertAdjacentHTML('beforeEnd', gtml)
                                    $('.admin_writing').addClass('hidden');
                                    var date = new Date();
                                    var day = date.getDate();
                                    localStorage["chat3_" + day] += gtml
                                }, 8000)

                            } else if (mode == "CHAT") {
                                console.log(100)
                                console.log("dasdasda")
                                setTimeout(function () {
                                    iconRefrash(false);
                                    $('.admin_writing').addClass('hidden');
                                    var gtml = `<div class="chat__comment bot"><div class="content">Товар поможет решить вашу проблему<br>Перейдите по этой ${silka} и заполните форму заказа, вам позвонят и ответят по телефону. Решать заказывать товар или нет, лучше после общения голосом.Вы в любой момент можете согласиться или отказаться от покупки.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                                    win.insertAdjacentHTML('beforeEnd', gtml)
                                    var date = new Date();
                                    var day = date.getDate();
                                    localStorage["chat3_" + day] += gtml
                                }, 3000)


                            }
                        }
                        if (mode != "COMMENT" && a == 2) {
                            localStorage['a2'] = 3;
                            console.log("sss2")
                            setTimeout(function () {
                                var gtml = `<div class="chat__comment bot"><div class="content">Здесь официальный сайт товара, подробно консультируют только по телефону<br>Всего доброго!</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                                win.insertAdjacentHTML('beforeEnd', gtml)
                                $('.admin_writing').addClass('hidden');
                                var date = new Date();
                                iconRefrash(false);
                                var day = date.getDate();
                                localStorage["chat3_" + day] += gtml
                            }, 8000)
                        }
                        if (mode == "COMMENT" && a == 2) {
                            localStorage['a2'] = 3;
                            console.log("all")
                            setTimeout(function () {
                                var gtml = `<div class="chat__comment bot"><div class="content">Извините, я должен отлучиться. Ответы на все свои вопросы вы можете получить по ссылкам выше.<br> До свидания.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                                win.insertAdjacentHTML('beforeEnd', gtml)
                                $('.admin_writing').addClass('hidden');
                                document.getElementById('stat').style = 'color:red'
                                document.getElementById('stat').innerText = 'Offline'
                                var date = new Date();
                                localStorage['status3'] = 1;
                                status = 1;
                                var day = date.getDate();
                                localStorage["chat3_" + day] += gtml;
                                iconRefrash(false);
                            }, 5000)
                        }
                        if (mode != "COMMENT" && a == 3) {
                            localStorage['a2'] = 4;
                            console.log("mmm")
                            setTimeout(function () {
                                iconRefrash(false)
                                var gtml = `<div class="chat__comment bot"><div class="content">Извините, я должен отлучиться. Ответы на все свои вопросы вы можете получить по ссылкам выше.<br> До свидания.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                                win.insertAdjacentHTML('beforeEnd', gtml)
                                $('.admin_writing').addClass('hidden');
                                document.getElementById('stat').style = 'color:red'
                                document.getElementById('stat').innerText = 'Offline'
                                var date = new Date();
                                localStorage['status3'] = 1;
                                status = 1;
                                var day = date.getDate();
                                localStorage["chat3_" + day] += gtml
                            }, 4000)
                        }a++
                    } else {
                        setTimeout(function () {
                            iconRefrash(false)
                            var gtml = `<div class="chat__comment bot"><div class="content">Верить или нет – ваше право.<br>Желаю удачи!</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                            win.insertAdjacentHTML('beforeEnd', gtml)
                            $('.admin_writing').addClass('hidden');
                            var date = new Date();
                            var day = date.getDate();
                            localStorage["chat3_" + day] += gtml
                        }, 4000)
                    }
                }

            }

        });

        $(".window-close").click(function () {
            console.log(21312)
            $(".chat-content").css("display", "none");
            $("body").css("overflow", "auto");
            chatbox = 0;
        });

    });

})(jQuery);

document.getElementById('plane').addEventListener('click', function () {
    console.log(a);
    console.log(mode, 1111);
    var gtml;
    var text = document.getElementById('popchat').value;
    document.getElementById('popchat').value = ""
    if (isValid(text)) {
        if (isGoodMesssag(text)) {
            var time = new Date(),
                win = document.getElementById('win'),
                now = ""
                    + time.getHours() + ":"
                    + time.getMinutes();

            var gtml = `<div class="chat__comment"><div class="content">${text}</div><div class="message-info"><p>Вы:</p>${now}</div></div>`
            win.insertAdjacentHTML('beforeEnd', gtml)
            var date = new Date();
            var day = date.getDate();
            localStorage["chat3_" + day] += gtml
            if(status != 1){
                $('.admin_writing').removeClass('hidden');
            }
            if (a == 1) {
                localStorage['a2'] = 2;
                $('.admin_writing').removeClass('hidden');
                if (mode == "COMMENT") {
                    console.log(100312312)
                    setTimeout(function () {
                        iconRefrash(false);
                        var gtml = `<div class="chat__comment bot"><div class="content">Здесь официальный сайт товара, подробно консультируют только по телефону<br>Всего доброго!</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                        win.insertAdjacentHTML('beforeEnd', gtml);
                        $('.admin_writing').addClass('hidden');
                        var date = new Date();
                        var day = date.getDate();
                        localStorage["chat3_" + day] += gtml
                    }, 4000)
                } else if (mode == "WAITING") {
                    console.log(34)
                    setTimeout(function () {
                        iconRefrash(false)
                        var gtml = `<div class="chat__comment bot"><div class="content">Перейдите по этой ${silka} и заполните форму заказа, вам позвонят и ответят по телефону. Решать заказывать товар или нет, лучше после общения голосом.Вы в любой момент можете согласиться или отказаться от покупки.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                        win.insertAdjacentHTML('beforeEnd', gtml)
                        $('.admin_writing').addClass('hidden');
                        var date = new Date();
                        var day = date.getDate();
                        localStorage["chat3_" + day] += gtml
                    }, 8000)

                } else if (mode == "CHAT") {
                    console.log(100)
                    console.log("dasdasda")
                    setTimeout(function () {
                        iconRefrash(false)
                        $('.admin_writing').addClass('hidden');
                        var gtml = `<div class="chat__comment bot"><div class="content">Товар поможет решить вашу проблему<br>Перейдите по этой ${silka} и заполните форму заказа, вам позвонят и ответят по телефону. Решать заказывать товар или нет, лучше после общения голосом.Вы в любой момент можете согласиться или отказаться от покупки.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                        win.insertAdjacentHTML('beforeEnd', gtml)
                        var date = new Date();
                        var day = date.getDate();
                        localStorage["chat3_" + day] += gtml
                    }, 3000)


                }
            }
            if (mode != "COMMENT" && a == 2) {
                localStorage['a2'] = 3;
                console.log("sss2")
                setTimeout(function () {
                    iconRefrash(false)
                    var gtml = `<div class="chat__comment bot"><div class="content">Здесь официальный сайт товара, подробно консультируют только по телефону<br>Всего доброго!</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                    win.insertAdjacentHTML('beforeEnd', gtml)
                    $('.admin_writing').addClass('hidden');
                    var date = new Date();
                    var day = date.getDate();
                    localStorage["chat3_" + day] += gtml
                }, 8000)
            }
            if (mode == "COMMENT" && a == 2) {
                localStorage['a2'] = 3;
                console.log("all")
                setTimeout(function () {
                    iconRefrash(false)
                    var gtml = `<div class="chat__comment bot"><div class="content">Извините, я должен отлучиться. Ответы на все свои вопросы вы можете получить по ссылкам выше.<br> До свидания.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                    win.insertAdjacentHTML('beforeEnd', gtml)
                    $('.admin_writing').addClass('hidden');
                    document.getElementById('stat').style = 'color:red'
                    document.getElementById('stat').innerText = 'Offline'
                    var date = new Date();
                    localStorage['status3'] = 1;
                    status = 1
                    var day = date.getDate();
                    localStorage["chat3_" + day] += gtml
                }, 5000)
            }
            if (mode != "COMMENT" && a == 3) {
                localStorage['a'] = 4;
                console.log("mmm")
                setTimeout(function () {
                    iconRefrash(false)
                    var gtml = `<div class="chat__comment bot"><div class="content">Извините, я должен отлучиться. Ответы на все свои вопросы вы можете получить по ссылкам выше.<br> До свидания.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                    win.insertAdjacentHTML('beforeEnd', gtml)
                    $('.admin_writing').addClass('hidden');
                    document.getElementById('stat').style = 'color:red'
                    document.getElementById('stat').innerText = 'Offline'
                    var date = new Date();
                    localStorage['status3'] = 1;
                    status = 1;
                    var day = date.getDate();
                    localStorage["chat3_" + day] += gtml
                }, 4000)
            }a++
        } else {
            setTimeout(function () {
                iconRefrash(false)
                var gtml = `<div class="chat__comment bot"><div class="content">Верить или нет – ваше право.<br>Желаю удачи!</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                win.insertAdjacentHTML('beforeEnd', gtml)
                $('.admin_writing').addClass('hidden');
                var date = new Date();
                var day = date.getDate();
                localStorage["chat3_" + day] += gtml
            }, 4000)
        }
    }
})


document.getElementById('comm').addEventListener('click', function () {

    var name = document.getElementById('comment-name').value,
        text = document.getElementById('comment-text').value;


    if (isValid(text)) {
        var time = new Date(),
            prev = document.getElementsByClassName('use'),
            now =
                + time.getHours() + ":"
                + time.getMinutes();

        $("#downHere").hide()
        setTimeout(function () {

            try {
                iconRefrash(true);
                $(".chat-content").css("display", "block")
                $('.chat-content').toggle("slide", {direction: "right"}, 5000)
                $("body").css("overflow", "hidden")
                chatbox = 1;

            } catch (e) {

            } finally {
                if (!alreadyOpened) {
                    alreadyOpened = true;
                    if (a == 0) {
                        mode = "COMMENT";
                        localStorage['mode2'] = 'COMMENT';
                        $('.admin_writing').removeClass('hidden');
                        a++
                        localStorage['a2'] = 1;
                        var win = document.getElementById('win')
                        setTimeout(function () {
                            $('.admin_writing').add('hidden');
                            var gtml = `<div class="chat__comment bot"><div class="content">Здравствуйтe ${name}<br>Я увидел ваше сообщение в комментарии.Перейдите по этой ${silka} и заполните форму заказа, вам позвонят и ответят по телефону. Решать заказывать товар или нет, лучше после общения голосом.Вы в любой момент можете согласиться или отказаться от покупки.</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                            win.insertAdjacentHTML('beforeEnd', gtml)
                            $('.admin_writing').addClass('hidden');
                            var date = new Date();
                            var day = date.getDate();
                            iconRefrash(false)
                            localStorage["chat3_" + day] = gtml

                        }, 10000)
                    }
                }
            }

        }, 7000)

        document.getElementById('comment-text').value = ''
        if (text.length < 2 || name.length < 2)
            return
        for (var i = 0; i < prev.length; i++)
            if (prev[i].innerText == text)
                return


        var html = `<div class="comment-item"><div class="comment-user-img"><img src="img/comment1.jpeg" alt="" /></div><div class="comment-user-name"><p>${name}</p><p><span>${text}.</span></p></div><div class="comment-text"><p>0 минуты назад</p></div></div>`;
        $("#downHere").addClass('hidden');
        $('.add-comm').removeClass('hidden');
        downHere.insertAdjacentHTML('beforeBegin', html)
        downHere.insertAdjacentHTML('beforeBegin',html)
        localStorage['limit22'] = limit
        localStorage['key22' + limit] = html
        limit++


    }
})


setTimeout(function () {


    iconRefrash(true)
    try {
        $(".chat-content").css("display", "block")
        $('.chat-content').toggle("slide", {direction: "right"}, 5000)
        $("body").css("overflow", "hidden")

    } catch (e) {

    } finally {
        if (a == 0) {
            $('.admin_writing').removeClass('hidden');
            mode = "WAITING";
            localStorage['mode2'] = 'WAITING';
            alreadyOpened = true
            if (a == 0) {
                localStorage['a2'] = 1;
                var win = document.getElementById('win'),
                    time = new Date(),
                    now = "" + time.getHours() + ":"
                        + time.getMinutes();

                setTimeout(function () {
                    var gtml = `<div class="chat__comment bot"><div class="content">Здравствуйтe!<br>Вы находитесь на моем сайте уже достаточно долго. У вас есть вопросы о товаре?</div><div class="message-info"><p>Михаил Глебов:</p>${now}</div></div><br>`
                    win.insertAdjacentHTML('beforeEnd', gtml)
                    $('.admin_writing').addClass('hidden');
                    var date = new Date();
                    var day = date.getDate();
                    a++
                    localStorage["chat3_" + day] = gtml
                }, 4000)
            }
        }
    }
}, 120000)
if(a == 0){
    setTimeout(function () {
        console.log(a)
        if (!alreadyOpened) {
            iconRefrash(false)
        }
    }, 30000)
}
var interval
function iconRefrash(type) {

    if (!type) {
        $('.one-message').removeClass('hidden')
        var open = true;
        interval = setInterval(function () {
            console.log(type)
            if (open) {
                $('.chat-icon img').css({height: '65px', width: '65px'})
                open = false;
            } else {
                $('.chat-icon img').css({height: '70px', width: '70px'})
                open = true;
            }
        }, 300)
    } else {
        $('.one-message').addClass('hidden')
        $('.chat-icon img').css({height: '70px', width: '70px'})
        clearInterval(interval);
    }
}

function isValid(text) {
    return text !== "";
}

function isGoodMesssag(text) {
    return true;
}